Unity 2017.1.0p4
Google VR SDK 1.120
https://medium.com/@sabarish.gnanamoorthy/vr-platforms-and-applications-vr-innovation-gallery-da9b47c2d12e
